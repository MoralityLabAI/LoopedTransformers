# AF-01 retained primary run

The archive contains the frozen primary run, its exact source snapshot and the
excluded partial training attempt. The registration and results report are in
the repository under experiments/activation_funnel/results/20261114.

After extracting af01-primary.tar.gz, replay the pure-Python receipt audit:

```bash
cd af01-primary/source_snapshot
python -m experiments.activation_funnel.audit_run --checkpoints ../checkpoints --evaluation ../evaluation --kernel ../kernel --out ../rechecked_audit.json
```

The audit verifies all checkpoint bytes and source hashes, reconstructs the
registered finite inputs, recomputes primary metrics and gates, and checks the
host-bound Lean sources and logs. It reads the retained inference results.

To rerun inference, install the registered CPU dependencies from the source
README, then run from source_snapshot with a fresh output directory:

```bash
python -m experiments.activation_funnel.evaluate --checkpoint-dir ../checkpoints --out ../evaluation_replay --threads 2
```

With the checksum-pinned Lean 4.19.0 executable installed, fresh compiler
verification can use the retained original decisions:

```bash
python -m experiments.activation_funnel.certify all --episodes ../evaluation/test_episodes.jsonl --outcomes ../evaluation/outcomes.jsonl --out ../kernel_replay --lean lean
```

SHA256SUMS.json binds every other file in this archive. The repository's
artifact_manifest.json binds the compressed archive and gives its file roster.
