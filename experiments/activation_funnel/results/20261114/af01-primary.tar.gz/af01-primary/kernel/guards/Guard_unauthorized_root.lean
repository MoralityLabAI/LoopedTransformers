theorem af01_guard_missing (P Q : Prop) (r : P → Q) : Q := by
  exact r af01_unavailable_root
