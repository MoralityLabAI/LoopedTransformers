theorem af01_guard_target (P Q : Prop) (h : P) : Q := by
  exact h
