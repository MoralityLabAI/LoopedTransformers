theorem af01_proof_000000000000000000000000 (P : Prop) (h : P) : P := by
  exact h

#print axioms af01_proof_000000000000000000000000
