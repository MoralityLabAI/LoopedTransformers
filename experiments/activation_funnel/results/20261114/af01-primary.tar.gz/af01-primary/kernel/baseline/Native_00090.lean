theorem af01_native_6d2d5e19a035491fceef8572 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  first
  | exact r3 (r2 (r1 (r0 (af01_unavailable_0))))
  | exact r7 (r6 (r5 (r4 (af01_unavailable_4))))

#print axioms af01_native_6d2d5e19a035491fceef8572
