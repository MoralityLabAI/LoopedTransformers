theorem af01_native_702448ef49c6f6244ad81c6c (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  first
  | exact r4 (r3 (r2 (r1 (r0 (af01_unavailable_0)))))
  | exact r9 (r8 (r7 (r6 (r5 (af01_unavailable_5)))))

#print axioms af01_native_702448ef49c6f6244ad81c6c
