theorem af01_proof_014ba1c06f5d0c8d5bf95cfe (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_014ba1c06f5d0c8d5bf95cfe

theorem af01_proof_05ba26054f0e455810311225 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_05ba26054f0e455810311225

theorem af01_proof_18608f9b595fcafaf0f87139 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_18608f9b595fcafaf0f87139

theorem af01_proof_1980c1aaf9fc68eb4f7436b6 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_1980c1aaf9fc68eb4f7436b6

theorem af01_proof_1b2a76b0fa1c5bb21ee901bf (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_1b2a76b0fa1c5bb21ee901bf

theorem af01_proof_1ba97e2bee84d3bf062ff172 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_1ba97e2bee84d3bf062ff172

theorem af01_proof_1cacc9d3c422000a6c893510 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_1cacc9d3c422000a6c893510

theorem af01_proof_21f325b957878df6fbb4488d (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_21f325b957878df6fbb4488d

theorem af01_proof_23582a8e07e8bf797b1577d5 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_23582a8e07e8bf797b1577d5

theorem af01_proof_23c0429b80a27d899646a941 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_23c0429b80a27d899646a941

theorem af01_proof_2663f3a809f0be0bb4a8171e (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_2663f3a809f0be0bb4a8171e

theorem af01_proof_2a2842bd57cc13884b18c62e (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_2a2842bd57cc13884b18c62e

theorem af01_proof_2b5d5285cb882b763ba33a04 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_2b5d5285cb882b763ba33a04

theorem af01_proof_2c441690c4f3851dfd8d700b (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_2c441690c4f3851dfd8d700b

theorem af01_proof_2fcfd2d8ca3546bb5339dbe7 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_2fcfd2d8ca3546bb5339dbe7

theorem af01_proof_3038e60a2c1ae07750aba391 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_3038e60a2c1ae07750aba391

theorem af01_proof_32c3d30625d0ba2e973e997e (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_32c3d30625d0ba2e973e997e

theorem af01_proof_3332a4c076ec537fdb00a924 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_3332a4c076ec537fdb00a924

theorem af01_proof_336069784448f1232374b506 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_336069784448f1232374b506

theorem af01_proof_3751377f5853ff6c7c046997 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_3751377f5853ff6c7c046997

theorem af01_proof_3827fec4141fb4b831a70f79 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_3827fec4141fb4b831a70f79

theorem af01_proof_388d8ba2cf8994a1c01e6973 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_388d8ba2cf8994a1c01e6973

theorem af01_proof_39a1b56ba4fada5d89b3756d (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_39a1b56ba4fada5d89b3756d

theorem af01_proof_39f12c2517e9cd5ba8eb7454 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_39f12c2517e9cd5ba8eb7454

theorem af01_proof_3a45b864b5ae55c4f7173795 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_3a45b864b5ae55c4f7173795

theorem af01_proof_3c6c58f86c2ab1a517822569 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_3c6c58f86c2ab1a517822569

theorem af01_proof_406642cf1359f86d0078e7eb (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_406642cf1359f86d0078e7eb

theorem af01_proof_4ad920d24fb399889dbe25bb (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_4ad920d24fb399889dbe25bb

theorem af01_proof_51cf00768705c367374719d6 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_51cf00768705c367374719d6

theorem af01_proof_5833c5ec95590fc082e4c570 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_5833c5ec95590fc082e4c570

theorem af01_proof_5afdee45dd6024cca4a361c6 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_5afdee45dd6024cca4a361c6

theorem af01_proof_5b4e9e7b32e5fbc65f4d73c8 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_5b4e9e7b32e5fbc65f4d73c8

theorem af01_proof_5e1536dd8e471461c30851cc (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_5e1536dd8e471461c30851cc

theorem af01_proof_5ec985d45db8584f4f3fbeca (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_5ec985d45db8584f4f3fbeca

theorem af01_proof_5fe4177900ede118c7050c40 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_5fe4177900ede118c7050c40

theorem af01_proof_5ff2718d30662570478e1e79 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_5ff2718d30662570478e1e79

theorem af01_proof_60fa275bfe1655705330a501 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_60fa275bfe1655705330a501

theorem af01_proof_61f1d1d4b2a404eff4064ca5 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_61f1d1d4b2a404eff4064ca5

theorem af01_proof_62b44647532667cc02dce69d (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_62b44647532667cc02dce69d

theorem af01_proof_6482da76f959778e38a6fb24 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_6482da76f959778e38a6fb24

theorem af01_proof_68c48783c527329fd2bc9e14 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_68c48783c527329fd2bc9e14

theorem af01_proof_697f0bb9f347796cfe3dcb04 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_697f0bb9f347796cfe3dcb04

theorem af01_proof_7098bc562387fa4636d2ee56 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_7098bc562387fa4636d2ee56

theorem af01_proof_73a4e2c0721a39c9a30f2e01 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_73a4e2c0721a39c9a30f2e01

theorem af01_proof_744d75a131aa347154dc2cc7 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_744d75a131aa347154dc2cc7

theorem af01_proof_7493fc3f953ee0bfa9cda96e (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_7493fc3f953ee0bfa9cda96e

theorem af01_proof_74d62f54b0b47ef2e3043462 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_74d62f54b0b47ef2e3043462

theorem af01_proof_761d368f58fcab33d12d4b13 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_761d368f58fcab33d12d4b13

theorem af01_proof_791ca876dc911469badd020c (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_791ca876dc911469badd020c

theorem af01_proof_7992cf5745229ea8f49b5328 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_7992cf5745229ea8f49b5328

theorem af01_proof_7a8586da1dbac370002c6b5c (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_7a8586da1dbac370002c6b5c

theorem af01_proof_7b92ea4bd7645696ee2344cb (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_7b92ea4bd7645696ee2344cb

theorem af01_proof_7d3055e17773203c2b75f03f (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_7d3055e17773203c2b75f03f

theorem af01_proof_7ec1fd15679c831024058d7a (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_7ec1fd15679c831024058d7a

theorem af01_proof_7f419f25b461b17c4d827f5d (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_7f419f25b461b17c4d827f5d

theorem af01_proof_801e5fd6520ce3218f4092f0 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_801e5fd6520ce3218f4092f0

theorem af01_proof_8dd1cbb94279ff44981f8c88 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_8dd1cbb94279ff44981f8c88

theorem af01_proof_8fa970814a4a04aa7bb0e76c (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_8fa970814a4a04aa7bb0e76c

theorem af01_proof_8ff6cbaa60e77ff2df4575c1 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_8ff6cbaa60e77ff2df4575c1

theorem af01_proof_919523bf2d2794c2bafaa3b7 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_919523bf2d2794c2bafaa3b7

theorem af01_proof_92f678ff5b9dd006f23952c6 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_92f678ff5b9dd006f23952c6

theorem af01_proof_97021abd02cc8f8fcd4d29e5 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_97021abd02cc8f8fcd4d29e5

theorem af01_proof_979f5d22e209cf38850ec604 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_979f5d22e209cf38850ec604

theorem af01_proof_99aa1fae98875086a79fbab9 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_99aa1fae98875086a79fbab9

theorem af01_proof_9b384f8208acaf2f72b504a1 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_9b384f8208acaf2f72b504a1

theorem af01_proof_9e382519e485e8d6dd0df7a6 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_9e382519e485e8d6dd0df7a6

theorem af01_proof_9e82923f00f05187ef70d104 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_9e82923f00f05187ef70d104

theorem af01_proof_a3a0f8afffcd9632c54f55e8 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_a3a0f8afffcd9632c54f55e8

theorem af01_proof_ad514080111b896df5aa7d3d (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_ad514080111b896df5aa7d3d

theorem af01_proof_ad82b50709edfd3e68b715fa (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_ad82b50709edfd3e68b715fa

theorem af01_proof_b1ffa32cc65bb3723b1e479c (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_b1ffa32cc65bb3723b1e479c

theorem af01_proof_bc9058a77f964563cd61fdea (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_bc9058a77f964563cd61fdea

theorem af01_proof_bf864455a9110b1a8d5de4c1 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_bf864455a9110b1a8d5de4c1

theorem af01_proof_bff8275758f345a7bb18cbfb (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_bff8275758f345a7bb18cbfb

theorem af01_proof_c38b080adb687909055b4705 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_c38b080adb687909055b4705

theorem af01_proof_c787eb1bc74de0f9ceee61e1 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_c787eb1bc74de0f9ceee61e1

theorem af01_proof_d02df71ef29bf56f8b078cc6 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_d02df71ef29bf56f8b078cc6

theorem af01_proof_d37e6fcbe544c0cc7dd94edd (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_d37e6fcbe544c0cc7dd94edd

theorem af01_proof_d73e87f542942f14c07d5644 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_d73e87f542942f14c07d5644

theorem af01_proof_d7e6ce39a6e7bd2347b9832f (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_d7e6ce39a6e7bd2347b9832f

theorem af01_proof_da916384bfd3f8c7fbfdb96c (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_da916384bfd3f8c7fbfdb96c

theorem af01_proof_db28ee70f7597159695429a3 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_db28ee70f7597159695429a3

theorem af01_proof_e4b8d16202c45032333a44ff (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_e4b8d16202c45032333a44ff

theorem af01_proof_e515826b455be1564fb4c075 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_e515826b455be1564fb4c075

theorem af01_proof_ea70eb960d9679443f608666 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_ea70eb960d9679443f608666

theorem af01_proof_ead87d3d43fb253866e4c48b (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_ead87d3d43fb253866e4c48b

theorem af01_proof_ed93bff3445a86612c44e39f (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_ed93bff3445a86612c44e39f

theorem af01_proof_ef44cc07c05886e5d54359c2 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_ef44cc07c05886e5d54359c2

theorem af01_proof_f1116e6f0097a869a6db1855 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_f1116e6f0097a869a6db1855

theorem af01_proof_f6ae2de5b1a563bd633dee04 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_f6ae2de5b1a563bd633dee04

theorem af01_proof_f7a12b0651cc0aca6dd233f2 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_f7a12b0651cc0aca6dd233f2

theorem af01_proof_fac89a7eae690be39873559d (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_fac89a7eae690be39873559d

theorem af01_proof_fc45a34ffbdad10f51b1f224 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f4 : P4) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r7 (r6 (r5 (r4 (f4))))

#print axioms af01_proof_fc45a34ffbdad10f51b1f224

theorem af01_proof_fe94921af753509f664593b4 (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f5 : P5) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r9 (r8 (r7 (r6 (r5 (f5)))))

#print axioms af01_proof_fe94921af753509f664593b4

theorem af01_proof_feebee52902715c5c69bdcf5 (P0 P1 P2 P3 P4 P5 P6 P7 P8 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P8) (r4 : P4 → P5) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) : P8 := by
  exact r3 (r2 (r1 (r0 (f0))))

#print axioms af01_proof_feebee52902715c5c69bdcf5

theorem af01_proof_ffb3a2aaf08534bb7bb76b1a (P0 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 : Prop) (f0 : P0) (r0 : P0 → P1) (r1 : P1 → P2) (r2 : P2 → P3) (r3 : P3 → P4) (r4 : P4 → P10) (r5 : P5 → P6) (r6 : P6 → P7) (r7 : P7 → P8) (r8 : P8 → P9) (r9 : P9 → P10) : P10 := by
  exact r4 (r3 (r2 (r1 (r0 (f0)))))

#print axioms af01_proof_ffb3a2aaf08534bb7bb76b1a
