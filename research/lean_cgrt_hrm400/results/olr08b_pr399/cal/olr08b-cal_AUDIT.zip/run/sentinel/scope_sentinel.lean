import Lean
namespace ScopeSentinel
theorem earlier (n : Nat) : n + 0 = n := Nat.add_zero n
@[simp] theorem current (n : Nat) : n + 0 = n := by
  exact earlier n
theorem later (n : Nat) : n + 0 = n := earlier n
end ScopeSentinel
